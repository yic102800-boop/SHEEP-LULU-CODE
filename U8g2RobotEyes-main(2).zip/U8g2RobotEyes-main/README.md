# U8g2RobotEyes

基于 U8g2 的 Arduino 单色机器人眼睛库，面向 128×64 OLED。库内包含两套完整的 20 表情主题：原始方眼主题和圆眼主题；两套主题共享平滑切换、持续微动作、眨眼和视线动画。

## 选择眼睛主题

默认使用方眼主题，不需要额外配置：

```cpp
#include <U8g2RobotEyes.h>
```

使用圆眼主题时，在包含库之前定义宏：

```cpp
#define U8G2_ROBOT_EYES_STYLE U8G2_ROBOT_EYES_STYLE_ROUND
#include <U8g2RobotEyes.h>
```

也可以显式选择方眼主题：

```cpp
#define U8G2_ROBOT_EYES_STYLE U8G2_ROBOT_EYES_STYLE_SQUARE
#include <U8g2RobotEyes.h>
```

宏通过构造函数的默认参数选择主题，因此在标准 Arduino 独立编译库源码的方式下也能正确工作。还可以绕过宏，在构造时显式指定：

```cpp
U8g2RobotEyes eyes(display, U8g2RobotEyes::ROUND_EYES);
```

## 设计参考

方眼主题：

![方眼主题](expression-reference-v2.png)

圆眼主题：

![圆眼主题](simulator/output/expression-sheet-round.png)

圆眼绘制器使用同心圆环、圆形虹膜和圆形瞳孔；爱心与旋涡在黑色眼腔中使用白色像素。两套主题现在使用完全一致的 20 种表情语义：圆眼“好奇”采用大小眼、同步向上探视和不对称挑眉；“邪恶”保留低矮窄眼、内压眼睑、细小瞳孔和对向凝视，并在两套主题中统一使用简洁的水平眼眶底边。

## 特性

- 20 种表情，两套主题使用相同枚举和 API。
- `smoothstep` 连续变形，动画中途再次切换不会跳回旧姿态。
- 每个表情都有持续微动作；大笑使用两只弧形闭眼同步上下弹动，方眼为阶梯式像素弧、圆眼为平滑抛物线弧。圆眼眼眶使用较细的连续圆角环，眼球为较小的实心圆点，不绘制内部眼核。
- “惊讶”使用高窄眼、小瞳孔和侧向闪光；“兴奋”使用宽扁眼、大瞳孔、抬高的水平眉毛，以及更快的上下弹跳和瞳孔脉动，两套风格保持相同语义但保留各自方圆轮廓。
- 非阻塞 `update()`，没有 `delay()`。
- 支持自动眨眼、随机视线和手动视线控制。
- `drawToBuffer()` 可与同屏文字或其他 UI 合成。
- 推荐 ESP32、ESP32-S3、RP2040 等 RAM 充足的 Arduino 兼容设备。

## 最小示例

```cpp
#define U8G2_ROBOT_EYES_STYLE U8G2_ROBOT_EYES_STYLE_ROUND
#include <U8g2lib.h>
#include <U8g2RobotEyes.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);
U8g2RobotEyes eyes(display);

void setup() {
  display.begin();
  eyes.begin(128, 64, 40);
  eyes.setAutoBlink(true);
  eyes.setIdle(true);
  eyes.setExpression(U8g2RobotEyes::HAPPY, 300);
}

void loop() {
  eyes.update();
}
```

## API

```cpp
eyes.setExpression(U8g2RobotEyes::ANGRY, 320);
eyes.setGaze(-6, 3, 180);          // x: -8..8, y: -7..7
eyes.centerGaze(180);
eyes.blink(180);
eyes.setAutoBlink(true, 3200, 1800);
eyes.setIdle(true, 1800);
eyes.isAnimating();
eyes.eyeStyle();
```

如需与其他内容共用 U8g2 buffer：

```cpp
display.clearBuffer();
eyes.drawToBuffer();
display.drawStr(0, 10, "status");
display.sendBuffer();
```

## 按键表情测试

`ExpressionGallery`（方眼）和 `RoundExpressionGallery`（圆眼）均提供手动测试模式：按键一端连接 `D0`，另一端连接 `GND`，程序使用 `INPUT_PULLUP` 和 30 ms 消抖。每次按下切换到下一个表情，切换时间为 320 ms。在 XIAO ESP32S3 上，`D0` 对应 GPIO1。

测试程序使用完整的 128×64 画面绘制眼睛，不显示文字或编号，并继续保持 40 FPS 微动作和周期眨眼。眉毛锚点基于表情的基础眼高，不会随眨眼开合上下滑动。

## 表情枚举

| 编号 | 枚举 | 表情 | 编号 | 枚举 | 表情 |
|---:|---|---|---:|---|---|
| 0 | `NEUTRAL` | 中性 | 10 | `LOVE` | 爱心 |
| 1 | `HAPPY` | 开心 | 11 | `WINK` | 眨眼 |
| 2 | `SAD` | 悲伤 | 12 | `LAUGHING` | 大笑 |
| 3 | `ANGRY` | 愤怒 | 13 | `CRYING` | 哭泣 |
| 4 | `SURPRISED` | 惊讶 | 14 | `BORED` | 无聊 |
| 5 | `SLEEPY` | 困倦 | 15 | `DETERMINED` | 坚定 |
| 6 | `SUSPICIOUS` | 怀疑 | 16 | `DIZZY` | 眩晕 |
| 7 | `EXCITED` | 兴奋 | 17 | `EMBARRASSED` | 害羞 |
| 8 | `SCARED` | 害怕 | 18 | `CURIOUS` | 好奇 |
| 9 | `THINKING` | 思考 | 19 | `EVIL` | 邪恶 |
