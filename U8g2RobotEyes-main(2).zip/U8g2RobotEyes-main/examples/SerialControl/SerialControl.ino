#include <Arduino.h>
#include <U8g2lib.h>
#include <U8g2RobotEyes.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);
U8g2RobotEyes eyes(display);

void setup() {
  Serial.begin(115200);
  display.begin();
  eyes.begin(128, 64, 40);
  eyes.setAutoBlink(true);
  Serial.println(F("Send expression number 0..19"));
}

void loop() {
  if (Serial.available()) {
    int value = Serial.parseInt();
    if (value >= 0 && value < U8g2RobotEyes::EXPRESSION_COUNT) {
      eyes.setExpression((U8g2RobotEyes::Expression)value, 320);
    }
    while (Serial.available()) Serial.read();
  }
  eyes.update();
}
