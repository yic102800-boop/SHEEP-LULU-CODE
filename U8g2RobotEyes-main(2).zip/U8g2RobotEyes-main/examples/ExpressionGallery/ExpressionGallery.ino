#include <Arduino.h>
#include <U8g2lib.h>
#include <U8g2RobotEyes.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);
U8g2RobotEyes eyes(display);

namespace {
constexpr uint8_t BUTTON_PIN = D0;       // XIAO ESP32S3: D0 = GPIO1
constexpr uint8_t DISPLAY_HEIGHT = 64;
constexpr uint16_t FRAME_INTERVAL_MS = 25;
constexpr uint16_t DEBOUNCE_MS = 30;

uint8_t expressionIndex = 0;
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;
uint32_t buttonChangedAt = 0;
uint32_t lastFrameAt = 0;
uint32_t nextBlinkAt = 0;

void selectNextExpression() {
  expressionIndex = (expressionIndex + 1) % U8g2RobotEyes::EXPRESSION_COUNT;
  eyes.setExpression(
      static_cast<U8g2RobotEyes::Expression>(expressionIndex), 320);
}

void updateButton(uint32_t now) {
  const bool reading = digitalRead(BUTTON_PIN);
  if (reading != lastButtonReading) {
    lastButtonReading = reading;
    buttonChangedAt = now;
  }

  if ((uint32_t)(now - buttonChangedAt) >= DEBOUNCE_MS &&
      reading != stableButtonState) {
    stableButtonState = reading;
    if (stableButtonState == LOW) selectNextExpression();
  }
}

void renderFrame(uint32_t now) {
  if ((uint32_t)(now - lastFrameAt) < FRAME_INTERVAL_MS) return;
  lastFrameAt = now;

  if ((int32_t)(now - nextBlinkAt) >= 0) {
    eyes.blink(180);
    nextBlinkAt = now + 3200;
  }

  display.clearBuffer();
  eyes.drawToBuffer();
  display.sendBuffer();
}
}  // namespace

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  lastButtonReading = stableButtonState = digitalRead(BUTTON_PIN);

  display.begin();
  eyes.begin(128, DISPLAY_HEIGHT, 40);
  const uint32_t now = millis();
  lastFrameAt = now - FRAME_INTERVAL_MS;
  nextBlinkAt = now + 3200;
}

void loop() {
  const uint32_t now = millis();
  updateButton(now);
  renderFrame(now);
}
