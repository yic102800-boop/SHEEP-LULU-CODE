#include <Arduino.h>
#include <U8g2lib.h>
#include <U8g2RobotEyes.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);
U8g2RobotEyes eyes(display);

void setup() {
  display.begin();
  eyes.begin(128, 64, 40);
  eyes.setExpression(U8g2RobotEyes::CURIOUS);
}

void loop() {
  // drawToBuffer() 不清屏、不发送，可与其他 U8g2 内容合成。
  display.clearBuffer();
  eyes.drawToBuffer();
  display.setFont(u8g2_font_4x6_tr);
  display.drawStr(1, 6, "ONLINE");
  display.sendBuffer();
  delay(25); // 示例 UI 的帧率控制；眼睛库本身不使用 delay。
}
