#pragma once

#include <Arduino.h>
#include <U8g2lib.h>

#define U8G2_ROBOT_EYES_STYLE_SQUARE 0
#define U8G2_ROBOT_EYES_STYLE_ROUND 1

#ifndef U8G2_ROBOT_EYES_STYLE
#define U8G2_ROBOT_EYES_STYLE U8G2_ROBOT_EYES_STYLE_SQUARE
#endif

#if U8G2_ROBOT_EYES_STYLE != U8G2_ROBOT_EYES_STYLE_SQUARE && \
    U8G2_ROBOT_EYES_STYLE != U8G2_ROBOT_EYES_STYLE_ROUND
#error "U8G2_ROBOT_EYES_STYLE must be SQUARE or ROUND"
#endif

class U8g2RobotEyes {
public:
  enum EyeStyle : uint8_t {
    SQUARE_EYES = U8G2_ROBOT_EYES_STYLE_SQUARE,
    ROUND_EYES = U8G2_ROBOT_EYES_STYLE_ROUND
  };

  enum Expression : uint8_t {
    NEUTRAL, HAPPY, SAD, ANGRY, SURPRISED,
    SLEEPY, SUSPICIOUS, EXCITED, SCARED, THINKING,
    CONFUSED = THINKING,  // Backward-compatible alias.
    LOVE, WINK, LAUGHING, CRYING, BORED,
    DETERMINED, DIZZY, EMBARRASSED, CURIOUS, EVIL,
    EXPRESSION_COUNT
  };

  explicit U8g2RobotEyes(
      U8G2 &display,
      EyeStyle style = (EyeStyle)U8G2_ROBOT_EYES_STYLE);

  void begin(uint8_t width = 128, uint8_t height = 64, uint8_t fps = 40);
  void update();                  // 限帧、清屏、绘制并发送 buffer
  void draw();                    // 立即清屏、绘制并发送 buffer
  void drawToBuffer();            // 只绘制，便于和其他 UI 合成

  void setExpression(Expression expression, uint16_t durationMs = 280);
  Expression expression() const { return targetExpression_; }
  bool isAnimating() const;

  void blink(uint16_t durationMs = 180);
  void setGaze(int8_t x, int8_t y, uint16_t durationMs = 180);
  void centerGaze(uint16_t durationMs = 180) { setGaze(0, 0, durationMs); }
  void setAutoBlink(bool enabled, uint16_t intervalMs = 3200,
                    uint16_t variationMs = 1800);
  void setIdle(bool enabled, uint16_t intervalMs = 1800);
  EyeStyle eyeStyle() const { return style_; }

private:
  struct Pose {
    int8_t widthL, widthR, heightL, heightR;
    int8_t gap, radius;
    int8_t innerTiltL, innerTiltR;              // 百分比，正值表示内侧下压
    int8_t topCutL, topCutR, bottomCutL, bottomCutR; // 眼高百分比
    int8_t pupilL, pupilR;
    int8_t gazeXL, gazeXR, gazeYL, gazeYR;
    int8_t faceX, faceY;
    int8_t browWidthL, browWidthR;
    int8_t browYL, browYR;
    int8_t browTiltL, browTiltR;
    uint8_t effectAmount;
    uint8_t effect;
    uint8_t symbolAmountL, symbolAmountR;
    uint8_t symbolL, symbolR;
  };

  enum Effect : uint8_t {
    FX_NONE, FX_HEART, FX_TEAR, FX_DIZZY, FX_BLUSH, FX_SPARK,
    FX_CURVED_BOTTOM
  };
  enum Symbol : uint8_t { SYM_NONE, SYM_WINK, SYM_LAUGH };

  U8G2 &u8g2_;
  EyeStyle style_;
  uint8_t screenW_, screenH_, fps_;
  uint32_t lastFrame_, transitionStart_, transitionDuration_;
  uint32_t blinkStart_, blinkDuration_, nextBlink_, nextIdle_;
  uint16_t autoBlinkInterval_, autoBlinkVariation_, idleInterval_;
  bool autoBlink_, idle_, blinking_;
  Expression targetExpression_;
  Pose from_, current_, target_;
  uint16_t transitionQ10_;
  uint32_t renderTime_;

  static const Pose squarePresets_[EXPRESSION_COUNT];
  static const Pose roundPresets_[EXPRESSION_COUNT];
  Pose preset(Expression expression) const;
  static uint16_t easeQ10(uint16_t t);
  static int8_t mix8(int8_t a, int8_t b, uint16_t t);
  void sample(uint32_t now);
  void applyMotion(Pose &pose, Expression expression, uint32_t now,
                   uint8_t amount) const;
  void scheduleBlink(uint32_t now);
  uint8_t blinkAmount(uint32_t now);
  void drawEye(int16_t cx, int16_t cy, bool left, const Pose &pose, uint8_t blink);
  void drawBrow(int16_t cx, int16_t eyeTop, int16_t eyeWidth, bool left,
                const Pose &pose);
  void drawSymbol(int16_t cx, int16_t cy, int16_t width, bool left,
                  uint8_t symbol, uint8_t scale);
  void drawHeart(int16_t cx, int16_t cy, uint8_t scale, uint8_t color);
  void drawSpiral(int16_t cx, int16_t cy, uint8_t scale, uint8_t color);
  void drawTear(int16_t x, int16_t y, uint8_t scale);
  void drawBlush(int16_t cx, int16_t y, uint8_t scale);
  void drawSpark(int16_t cx, int16_t y, uint8_t scale);
  void drawCurvedBottomCut(int16_t x, int16_t y, int16_t width,
                           int16_t height, int16_t cut, bool outline);
};
