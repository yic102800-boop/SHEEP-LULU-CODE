#include "U8g2RobotEyes.h"
#include <math.h>

#define EYES_PRESET(name, ...) {__VA_ARGS__},
const U8g2RobotEyes::Pose U8g2RobotEyes::squarePresets_[] = {
#include "U8g2RobotEyesSquarePresets.inc"
};
const U8g2RobotEyes::Pose U8g2RobotEyes::roundPresets_[] = {
#include "U8g2RobotEyesRoundPresets.inc"
};
#undef EYES_PRESET

static int8_t waveAt(uint32_t now, uint16_t period, int8_t amplitude,
                     uint16_t phase = 0) {
  const float angle = 6.2831853f * ((now + phase) % period) / period;
  return (int8_t)lroundf(sinf(angle) * amplitude);
}

static uint8_t blendU8(uint8_t a, uint8_t b, uint16_t t) {
  return (uint8_t)(a + ((int16_t)b - a) * (int16_t)t / 1024);
}

U8g2RobotEyes::U8g2RobotEyes(U8G2 &display, EyeStyle style)
    : u8g2_(display), style_(style), screenW_(128), screenH_(64), fps_(40), lastFrame_(0),
      transitionStart_(0), transitionDuration_(1), blinkStart_(0),
      blinkDuration_(180), nextBlink_(0), nextIdle_(0),
      autoBlinkInterval_(3200), autoBlinkVariation_(1800), idleInterval_(1800),
      autoBlink_(false), idle_(false), blinking_(false),
      targetExpression_(NEUTRAL), transitionQ10_(1024), renderTime_(0) {}

void U8g2RobotEyes::begin(uint8_t width, uint8_t height, uint8_t fps) {
  screenW_ = width;
  screenH_ = height;
  fps_ = fps ? fps : 40;
  current_ = from_ = target_ = preset(NEUTRAL);
  transitionStart_ = lastFrame_ = millis();
  transitionQ10_ = 1024;
  scheduleBlink(transitionStart_);
  nextIdle_ = transitionStart_ + idleInterval_;
}

uint16_t U8g2RobotEyes::easeQ10(uint16_t t) {
  if (t >= 1024) return 1024;
  return (uint32_t)t * t * (3072UL - 2UL * t) / 1048576UL;
}

int8_t U8g2RobotEyes::mix8(int8_t a, int8_t b, uint16_t t) {
  return (int8_t)(a + ((int16_t)(b - a) * (int16_t)t) / 1024);
}

U8g2RobotEyes::Pose U8g2RobotEyes::preset(Expression e) const {
  if (e >= EXPRESSION_COUNT) e = NEUTRAL;
  return style_ == ROUND_EYES ? roundPresets_[e] : squarePresets_[e];
}

void U8g2RobotEyes::sample(uint32_t now) {
  uint32_t elapsed = (uint32_t)(now - transitionStart_);
  uint16_t linear = elapsed >= transitionDuration_
                        ? 1024
                        : (uint16_t)(elapsed * 1024UL / transitionDuration_);
  uint16_t t = transitionQ10_ = easeQ10(linear);

#define MORPH(field) current_.field = mix8(from_.field, target_.field, t)
  MORPH(widthL); MORPH(widthR); MORPH(heightL); MORPH(heightR);
  MORPH(gap); MORPH(radius);
  MORPH(innerTiltL); MORPH(innerTiltR);
  MORPH(topCutL); MORPH(topCutR); MORPH(bottomCutL); MORPH(bottomCutR);
  MORPH(pupilL); MORPH(pupilR);
  MORPH(gazeXL); MORPH(gazeXR); MORPH(gazeYL); MORPH(gazeYR);
  MORPH(faceX); MORPH(faceY);
  MORPH(browWidthL); MORPH(browWidthR); MORPH(browYL); MORPH(browYR);
  MORPH(browTiltL); MORPH(browTiltR);
#undef MORPH

  if (from_.effect == target_.effect) {
    current_.effect = target_.effect;
    current_.effectAmount = blendU8(from_.effectAmount, target_.effectAmount, t);
  } else if (t < 512) {
    current_.effect = from_.effect;
    current_.effectAmount = (uint8_t)((uint32_t)from_.effectAmount *
        (1024 - easeQ10(t * 2)) / 1024);
  } else {
    current_.effect = target_.effect;
    current_.effectAmount = (uint8_t)((uint32_t)target_.effectAmount *
        easeQ10((t - 512) * 2) / 1024);
  }

#define MORPH_SYMBOL(side) \
  if (from_.symbol##side == target_.symbol##side) { \
    current_.symbol##side = target_.symbol##side; \
    current_.symbolAmount##side = blendU8(from_.symbolAmount##side, \
                                           target_.symbolAmount##side, t); \
  } else if (t < 512) { \
    current_.symbol##side = from_.symbol##side; \
    current_.symbolAmount##side = (uint8_t)((uint32_t)from_.symbolAmount##side * \
        (1024 - easeQ10(t * 2)) / 1024); \
  } else { \
    current_.symbol##side = target_.symbol##side; \
    current_.symbolAmount##side = (uint8_t)((uint32_t)target_.symbolAmount##side * \
        easeQ10((t - 512) * 2) / 1024); \
  }
  MORPH_SYMBOL(L);
  MORPH_SYMBOL(R);
#undef MORPH_SYMBOL
}

void U8g2RobotEyes::applyMotion(Pose &p, Expression e, uint32_t now,
                                 uint8_t amount) const {
  int8_t a = amount;
#define SCALED(value) ((int16_t)(value) * a / 255)
  switch (e) {
    case NEUTRAL: {
      int8_t look = waveAt(now, 4200, 1);
      p.gazeXL += SCALED(look); p.gazeXR += SCALED(look);
      break;
    }
    case HAPPY: {
      int8_t breathe = waveAt(now, 1800, 1);
      p.faceY += SCALED(breathe);
      p.bottomCutL += SCALED(waveAt(now, 1800, 2));
      p.bottomCutR = p.bottomCutL;
      break;
    }
    case SAD:
      p.gazeYL += SCALED(waveAt(now, 2600, 1));
      p.gazeYR = p.gazeYL;
      p.browYL += SCALED(waveAt(now, 2600, 1, 650));
      p.browYR = p.browYL;
      break;
    case ANGRY:
      p.faceX += SCALED(waveAt(now, 170, 1));
      break;
    case SURPRISED: {
      int8_t pulse = waveAt(now, 1100, 1);
      p.pupilL += SCALED(pulse); p.pupilR += SCALED(pulse);
      break;
    }
    case SLEEPY: {
      int8_t droop = waveAt(now, 3000, 4);
      p.topCutL += SCALED(droop); p.topCutR += SCALED(droop);
      break;
    }
    case SUSPICIOUS: {
      int8_t scan = waveAt(now, 2200, 2);
      p.gazeXL += SCALED(scan); p.gazeXR += SCALED(scan);
      break;
    }
    case EXCITED: {
      p.faceY += SCALED(waveAt(now, 430, 2));
      int8_t pulse = waveAt(now, 700, 2);
      p.pupilL += SCALED(pulse);
      p.pupilR += SCALED(pulse);
      break;
    }
    case SCARED:
      p.faceX += SCALED(waveAt(now, 130, 1));
      p.faceY += SCALED(waveAt(now, 170, 1, 40));
      break;
    case THINKING: {
      // Read as "recalling/searching" through the eyes themselves: both
      // pupils stay high and slowly search sideways while the narrowed right
      // eye and raised left brow move in counterpoint. No detached icon is
      // needed, which also keeps the 128x64 silhouette clean.
      int8_t search = waveAt(now, 3000, 2);
      int8_t recall = waveAt(now, 2200, 1, 650);
      p.gazeXL += SCALED(search); p.gazeXR += SCALED(search);
      p.gazeYL -= SCALED(recall); p.gazeYR -= SCALED(recall);
      p.topCutR += SCALED(waveAt(now, 2600, 2, 420));
      p.browYL -= SCALED(waveAt(now, 2600, 1, 420));
      p.browYR += SCALED(waveAt(now, 2600, 1, 420));
      break;
    }
    case LOVE: {
      uint8_t desired = (uint8_t)(228 + waveAt(now, 900, 26));
      p.effectAmount += ((int16_t)desired - p.effectAmount) * a / 255;
      p.faceY += SCALED(waveAt(now, 1800, 1));
      break;
    }
    case WINK:
      p.gazeXL += SCALED(waveAt(now, 1800, 1));
      p.faceY += SCALED(waveAt(now, 1500, 1));
      break;
    case LAUGHING: {
      p.faceY += SCALED(waveAt(now, 480, 3));
      break;
    }
    case CRYING:
      p.browYL += SCALED(waveAt(now, 1900, 1));
      p.browYR = p.browYL;
      break;
    case BORED: {
      int8_t drift = waveAt(now, 5000, 2);
      p.gazeXL += SCALED(drift); p.gazeXR += SCALED(drift);
      break;
    }
    case DETERMINED:
      p.faceY += SCALED(waveAt(now, 2400, 1));
      break;
    case DIZZY:
      p.faceX += SCALED(waveAt(now, 1200, 1));
      p.faceY += SCALED(waveAt(now, 1200, 1, 300));
      break;
    case EMBARRASSED: {
      uint8_t desired = (uint8_t)(220 + waveAt(now, 1200, 30));
      p.effectAmount += ((int16_t)desired - p.effectAmount) * a / 255;
      p.gazeXL += SCALED(waveAt(now, 2800, 1));
      p.gazeXR = -p.gazeXL;
      break;
    }
    case CURIOUS:
      p.faceY += SCALED(waveAt(now, 1900, 1));
      p.gazeYL += SCALED(waveAt(now, 2400, 1));
      p.gazeYR = p.gazeYL;
      p.browYL += SCALED(waveAt(now, 2000, 1));
      break;
    case EVIL: {
      int8_t stalk = waveAt(now, 2600, 1);
      p.gazeXL += SCALED(stalk); p.gazeXR -= SCALED(stalk);
      p.heightL += SCALED(waveAt(now, 1800, 1));
      p.heightR = p.heightL;
      break;
    }
    default:
      break;
  }
#undef SCALED
}

void U8g2RobotEyes::setExpression(Expression e, uint16_t durationMs) {
  if (e >= EXPRESSION_COUNT) return;
  uint32_t now = millis();
  sample(now);
  Pose visible = current_;
  applyMotion(visible, targetExpression_, now, (uint8_t)(transitionQ10_ >> 2));
  from_ = visible;
  target_ = preset(e);
  targetExpression_ = e;
  transitionStart_ = now;
  transitionDuration_ = durationMs ? durationMs : 1;
  transitionQ10_ = 0;
}

void U8g2RobotEyes::setGaze(int8_t x, int8_t y, uint16_t durationMs) {
  uint32_t now = millis();
  Pose desired = target_;
  sample(now);
  Pose visible = current_;
  applyMotion(visible, targetExpression_, now, (uint8_t)(transitionQ10_ >> 2));
  from_ = visible;
  target_ = desired;
  int8_t gx = constrain(x, -8, 8);
  int8_t gy = constrain(y, -7, 7);
  Pose base = preset(targetExpression_);
  target_.gazeXL = base.gazeXL + gx; target_.gazeXR = base.gazeXR + gx;
  target_.gazeYL = base.gazeYL + gy; target_.gazeYR = base.gazeYR + gy;
  transitionStart_ = now;
  transitionDuration_ = durationMs ? durationMs : 1;
  transitionQ10_ = 0;
}

bool U8g2RobotEyes::isAnimating() const {
  return blinking_ || (uint32_t)(millis() - transitionStart_) < transitionDuration_;
}

void U8g2RobotEyes::blink(uint16_t durationMs) {
  blinking_ = true;
  blinkStart_ = millis();
  blinkDuration_ = durationMs ? durationMs : 1;
}

void U8g2RobotEyes::scheduleBlink(uint32_t now) {
  uint16_t extra = autoBlinkVariation_ ? (uint16_t)random(autoBlinkVariation_ + 1UL) : 0;
  nextBlink_ = now + autoBlinkInterval_ + extra;
}

void U8g2RobotEyes::setAutoBlink(bool enabled, uint16_t intervalMs,
                                  uint16_t variationMs) {
  autoBlink_ = enabled;
  autoBlinkInterval_ = intervalMs;
  autoBlinkVariation_ = variationMs;
  scheduleBlink(millis());
}

void U8g2RobotEyes::setIdle(bool enabled, uint16_t intervalMs) {
  idle_ = enabled;
  idleInterval_ = intervalMs;
  nextIdle_ = millis() + idleInterval_;
}

uint8_t U8g2RobotEyes::blinkAmount(uint32_t now) {
  if (!blinking_) return 0;
  uint32_t elapsed = (uint32_t)(now - blinkStart_);
  if (elapsed >= blinkDuration_) {
    blinking_ = false;
    return 0;
  }
  uint16_t phase = (uint16_t)(elapsed * 2048UL / blinkDuration_);
  uint16_t triangle = phase <= 1024 ? phase : 2048 - phase;
  return (uint8_t)(easeQ10(triangle) >> 2);
}

void U8g2RobotEyes::update() {
  uint32_t now = millis();
  uint32_t framePeriod = 1000UL / fps_;
  if ((uint32_t)(now - lastFrame_) < framePeriod) return;
  lastFrame_ = now;

  if (autoBlink_ && (int32_t)(now - nextBlink_) >= 0) {
    blink();
    scheduleBlink(now);
  }
  if (idle_ && (int32_t)(now - nextIdle_) >= 0 && !isAnimating()) {
    setGaze((int8_t)random(-7, 8), (int8_t)random(-5, 6), 220);
    nextIdle_ = now + idleInterval_ + (uint16_t)random(901);
  }
  u8g2_.clearBuffer();
  drawToBuffer();
  u8g2_.sendBuffer();
}

void U8g2RobotEyes::draw() {
  u8g2_.clearBuffer();
  drawToBuffer();
  u8g2_.sendBuffer();
}

void U8g2RobotEyes::drawToBuffer() {
  renderTime_ = millis();
  sample(renderTime_);
  Pose animated = current_;
  applyMotion(animated, targetExpression_, renderTime_,
              (uint8_t)(transitionQ10_ >> 2));
  uint8_t blink = blinkAmount(renderTime_);
  int16_t leftCx = (screenW_ - animated.gap - animated.widthL) / 2 + animated.faceX;
  int16_t rightCx = (screenW_ + animated.gap + animated.widthR) / 2 + animated.faceX;
  int16_t cy = screenH_ / 2 + animated.faceY;
  drawEye(leftCx, cy, true, animated, blink);
  drawEye(rightCx, cy, false, animated, blink);
}

void U8g2RobotEyes::drawEye(int16_t cx, int16_t cy, bool left,
                             const Pose &p, uint8_t blink) {
  int16_t w = left ? p.widthL : p.widthR;
  int16_t baseH = left ? p.heightL : p.heightR;
  uint8_t symbol = left ? p.symbolL : p.symbolR;
  uint8_t symbolAmount = left ? p.symbolAmountL : p.symbolAmountR;
  uint16_t openScale = (uint16_t)(255 - symbolAmount) * (255 - blink) / 255;
  int16_t h = (int16_t)baseH * openScale / 255;
  if (w < 4) w = 4;

  int16_t visibleH = h < 3 ? 3 : h;
  // Brows belong to the expression pose, not to the temporary blink height.
  // Anchoring them to h made steep brows slide downward during a blink and
  // enter the screen as two clipped line fragments.
  const int16_t browTop = cy - baseH / 2;
  if (h >= 3 && openScale > 8) {
    int16_t x = cx - w / 2;
    int16_t y = cy - h / 2;
    uint8_t radius = (uint8_t)min((int16_t)(min(w, h) / 2),
                                  (int16_t)p.radius);
    u8g2_.setDrawColor(1);
    u8g2_.drawRBox(x, y, w, h, radius);

    const bool roundStyle = style_ == ROUND_EYES;
    if (roundStyle) {
      int16_t ring = constrain(min(w, h) / 10, 2, 3);
      int16_t innerW = w - ring * 2;
      int16_t innerH = h - ring * 2;
      if (innerW >= 4 && innerH >= 4) {
        int16_t innerRadiusValue = (int16_t)radius - ring;
        if (innerRadiusValue < 1) innerRadiusValue = 1;
        uint8_t innerRadius = (uint8_t)innerRadiusValue;
        u8g2_.setDrawColor(0);
        u8g2_.drawRBox(x + ring, y + ring, innerW, innerH, innerRadius);
      }
    }

    int8_t topCut = left ? p.topCutL : p.topCutR;
    int8_t bottomCut = left ? p.bottomCutL : p.bottomCutR;
    int8_t tilt = left ? p.innerTiltL : p.innerTiltR;
    int16_t outerY = y + (int16_t)h * topCut / 100;
    int16_t innerY = outerY + (int16_t)tilt * w / 100;
    outerY = constrain(outerY, y, y + h - 2);
    innerY = constrain(innerY, y, y + h - 2);
    int16_t yLeft = left ? outerY : innerY;
    int16_t yRight = left ? innerY : outerY;

    if (!roundStyle) {
      u8g2_.setDrawColor(0);
      if (topCut > 0 || tilt != 0) {
        u8g2_.drawTriangle(x - 2, y - 2, x + w + 2, y - 2,
                           x + w + 2, yRight);
        u8g2_.drawTriangle(x - 2, y - 2, x + w + 2, yRight,
                           x - 2, yLeft);
      }
      if (bottomCut > 0 && h > 8) {
        int16_t cut = (int16_t)h * bottomCut / 100;
        if (p.effect == FX_CURVED_BOTTOM)
          drawCurvedBottomCut(x, y, w, h, cut, false);
        else
          u8g2_.drawTriangle(x - 2, y + h + 2, x + w + 2, y + h + 2,
                             x + w / 2, y + h - cut);
      }
    }

    int8_t pupil = left ? p.pupilL : p.pupilR;
    int8_t gazeX = left ? p.gazeXL : p.gazeXR;
    int8_t gazeY = left ? p.gazeYL : p.gazeYR;
    if (p.effect == FX_HEART && p.effectAmount > 12) {
      drawHeart(cx, cy, p.effectAmount, roundStyle ? 1 : 0);
    } else if (p.effect == FX_DIZZY && p.effectAmount > 12) {
      drawSpiral(cx, cy, p.effectAmount, roundStyle ? 1 : 0);
    } else if (pupil >= 2 && h > 9) {
      int16_t px = cx + gazeX;
      int16_t py = cy + gazeY;
      if (roundStyle) {
        int16_t eyeBallRadius = min(w, h) / 7 + pupil / 4 - 1;
        eyeBallRadius = constrain(eyeBallRadius, 2, 8);
        u8g2_.setDrawColor(1);
        u8g2_.drawDisc(px, py, eyeBallRadius);
      } else {
        u8g2_.setDrawColor(0);
        u8g2_.drawRBox(px - pupil / 2, py - pupil / 2, pupil, pupil, 1);
      }
    }

    if (roundStyle) {
      u8g2_.setDrawColor(0);
      if (topCut > 0 || tilt != 0) {
        u8g2_.drawTriangle(x - 2, y - 2, x + w + 2, y - 2,
                           x + w + 2, yRight);
        u8g2_.drawTriangle(x - 2, y - 2, x + w + 2, yRight,
                           x - 2, yLeft);
      }
      if (bottomCut > 0 && h > 8) {
        int16_t cut = (int16_t)h * bottomCut / 100;
        if (p.effect == FX_CURVED_BOTTOM)
          drawCurvedBottomCut(x, y, w, h, cut, true);
        else
          u8g2_.drawTriangle(x - 2, y + h + 2, x + w + 2, y + h + 2,
                             x + w / 2, y + h - cut);
      }
    }
  }

  if (symbol != SYM_NONE && symbolAmount > 8)
    drawSymbol(cx, cy, w, left, symbol, symbolAmount);
  drawBrow(cx, browTop, w, left, p);

  if (p.effect == FX_TEAR && p.effectAmount > 12)
    drawTear(cx + (left ? -w / 4 : w / 4), cy + visibleH / 2 - 8,
             p.effectAmount);
  if (p.effect == FX_BLUSH && p.effectAmount > 12)
    drawBlush(cx, cy + visibleH / 2 + 4, p.effectAmount);
  if (p.effect == FX_SPARK && p.effectAmount > 12)
    drawSpark(cx, cy - visibleH / 2 - 3, p.effectAmount);
  u8g2_.setDrawColor(1);
}

void U8g2RobotEyes::drawBrow(int16_t cx, int16_t eyeTop, int16_t eyeWidth,
                              bool left, const Pose &p) {
  int16_t width = left ? p.browWidthL : p.browWidthR;
  if (width < 4) return;
  int8_t yOffset = left ? p.browYL : p.browYR;
  int8_t tilt = left ? p.browTiltL : p.browTiltR;
  int16_t outerX = left ? cx - width / 2 : cx + width / 2;
  int16_t innerX = left ? cx + width / 2 : cx - width / 2;
  int16_t outerY = eyeTop + yOffset;
  int16_t innerY = outerY + (int16_t)tilt * eyeWidth / 100;
  u8g2_.setDrawColor(1);
  for (int8_t i = 0; i < 3; ++i)
    u8g2_.drawLine(outerX, outerY + i, innerX, innerY + i);
}

void U8g2RobotEyes::drawSymbol(int16_t cx, int16_t cy, int16_t width,
                                bool left, uint8_t symbol, uint8_t scale) {
  int16_t half = (int32_t)width * 38 * scale / 25500L;
  int16_t rise = 7UL * scale / 255;
  if (half < 2) half = 2;
  if (rise < 2) rise = 2;
  u8g2_.setDrawColor(1);
  if (symbol == SYM_WINK) {
    int16_t innerX = left ? cx + half : cx - half;
    int16_t outerX = left ? cx - half : cx + half;
    for (int8_t i = 0; i < 3; ++i) {
      u8g2_.drawLine(outerX, cy - rise + i, innerX, cy + i);
      u8g2_.drawLine(innerX, cy + i, outerX, cy + rise + i);
    }
  } else if (symbol == SYM_LAUGH) {
    int32_t divisor = (int32_t)half * half;
    for (int16_t x = -half; x <= half; ++x) {
      int16_t curve = (int32_t)x * x * rise / divisor;
      if (style_ == SQUARE_EYES) curve = curve / 2 * 2;
      int16_t y = cy - rise + curve;
      for (int8_t thickness = 0; thickness < 3; ++thickness)
        u8g2_.drawPixel(cx + x, y + thickness);
    }
  }
}

void U8g2RobotEyes::drawHeart(int16_t cx, int16_t cy, uint8_t scale,
                              uint8_t color) {
  int16_t s = 7UL * scale / 255;
  if (s < 2) s = 2;
  u8g2_.setDrawColor(color);
  uint8_t lobe = (uint8_t)(s / 2);
  if (lobe < 1) lobe = 1;
  u8g2_.drawDisc(cx - s / 2, cy - s / 3, lobe);
  u8g2_.drawDisc(cx + s / 2, cy - s / 3, lobe);
  u8g2_.drawTriangle(cx - s, cy - s / 3, cx + s, cy - s / 3, cx, cy + s);
}

void U8g2RobotEyes::drawSpiral(int16_t cx, int16_t cy, uint8_t scale,
                               uint8_t color) {
  u8g2_.setDrawColor(color);
  int16_t px = cx, py = cy;
  float rotation = renderTime_ * 0.0045f;
  uint8_t count = (uint8_t)(7 + 17UL * scale / 255);
  for (uint8_t i = 1; i < count; ++i) {
    float angle = rotation + i * 0.72f;
    float radius = i * 0.34f * scale / 255.0f;
    int16_t nx = cx + (int16_t)lroundf(cosf(angle) * radius);
    int16_t ny = cy + (int16_t)lroundf(sinf(angle) * radius);
    u8g2_.drawLine(px, py, nx, ny);
    px = nx; py = ny;
  }
}

void U8g2RobotEyes::drawTear(int16_t x, int16_t y, uint8_t scale) {
  int16_t s = 4UL * scale / 255;
  if (s < 1) s = 1;
  int16_t fall = (renderTime_ / 85) % 9;
  y += fall;
  u8g2_.setDrawColor(1);
  u8g2_.drawDisc(x, y + s, s);
  u8g2_.drawTriangle(x, y - s, x - s, y + s, x + s, y + s);
}

void U8g2RobotEyes::drawBlush(int16_t cx, int16_t y, uint8_t scale) {
  int16_t length = 4UL * scale / 255;
  if (length < 1) length = 1;
  u8g2_.setDrawColor(1);
  for (int8_t i = -1; i <= 1; ++i) {
    int16_t x = cx - 2 + i * 5;
    u8g2_.drawLine(x, y + length, x + length, y);
  }
}

void U8g2RobotEyes::drawSpark(int16_t cx, int16_t y, uint8_t scale) {
  int16_t s = 4UL * scale / 255;
  if (s < 1) s = 1;
  u8g2_.setDrawColor(1);
  // Do not draw a centre glint: even a three-pixel diamond reads as one
  // detached vertical bar per eye on a physical 128x64 OLED. The two shallow
  // side rays retain the animated sparkle without adding vertical artifacts.
  u8g2_.drawLine(cx - s - 3, y - 1, cx - 3, y);
  u8g2_.drawLine(cx + 3, y, cx + s + 3, y - 1);
}

void U8g2RobotEyes::drawCurvedBottomCut(int16_t x, int16_t y,
                                        int16_t width, int16_t height,
                                        int16_t cut, bool outline) {
  if (width < 3 || height < 3 || cut < 1) return;
  const int32_t span = width - 1;
  const int32_t denominator = span * span;
  u8g2_.setDrawColor(0);
  for (int16_t column = 0; column < width; ++column) {
    const int32_t distance = 2L * column - span;
    int16_t rise = (int16_t)((int32_t)cut *
        (denominator - distance * distance) / denominator);
    if (rise > 0)
      u8g2_.drawVLine(x + column, y + height - rise, rise + 2);
  }
  if (!outline) return;

  // A round eye is an outline, so a black cut alone leaves its bottom open.
  // Redraw the new boundary as a two-pixel arc. Near the sides, clip that arc
  // against the original rounded-box silhouette; drawing every parabola
  // column would otherwise protrude beyond a capsule-shaped round eye.
  u8g2_.setDrawColor(1);
  const int16_t radius = min(width, height) / 2;
  const int32_t radiusSquared = (int32_t)(radius - 1) * (radius - 1);
  for (int16_t column = 0; column < width; ++column) {
    const int32_t distance = 2L * column - span;
    int16_t rise = (int16_t)((int32_t)cut *
        (denominator - distance * distance) / denominator);
    if (rise > 0) {
      const int16_t edgeY = y + height - rise - 1;
      bool insideRoundedEye = true;
      if (radius > 1 && column < radius) {
        const int16_t dx = column - (radius - 1);
        const int16_t dy = (edgeY - y) - (height - radius);
        insideRoundedEye = (int32_t)dx * dx + (int32_t)dy * dy <=
                           radiusSquared;
      } else if (radius > 1 && column >= width - radius) {
        const int16_t dx = column - (width - radius);
        const int16_t dy = (edgeY - y) - (height - radius);
        insideRoundedEye = (int32_t)dx * dx + (int32_t)dy * dy <=
                           radiusSquared;
      }
      if (!insideRoundedEye) continue;
      u8g2_.drawPixel(x + column, edgeY);
      u8g2_.drawPixel(x + column, edgeY - 1);
    }
  }
}
